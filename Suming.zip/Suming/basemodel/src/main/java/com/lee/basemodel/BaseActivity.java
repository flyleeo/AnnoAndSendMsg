package com.lee.basemodel;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.lee.basemodel.anno.BindViews;
import com.lee.basemodel.anno.Click;
import com.lee.basemodel.anno.LayoutView;
import com.lee.basemodel.anno.MsgAction;
import com.lee.basemodel.msg.MsgUtils;
import com.lee.basemodel.msg.Result;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by lee.
 * Time 2017/1/6 21:48
 * 基于反射的一个注解框架,因为用到反射效率会有点低.
 */

public abstract class BaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initAnnoLayout();
        initViews();
        initClick();
        initMsg();
        afterInitView();
    }

    /**
     * 解析消息注解
     * 未完善 一个activity只能接受一个消息.
     *
     */
    private void initMsg() {
        try {
            Method[] declaredMethods = getClass().getDeclaredMethods();
            for (Method method : declaredMethods) {
                MsgAction annotation = method.getAnnotation(MsgAction.class);
                if (annotation == null) {
                    continue;
                }
                MsgUtils.getInstance().addObservable(annotation.name(), new Result() {
                    @Override
                    public void getResult(Object o) {
                    }
                });

                proxyResult(method, annotation);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 等待弹框
     */
    private ProgressDialog progressDialog;

    /**
     * 延迟等待时出现的弹框
     */
    public void showProgress() {
        progressDialog = ProgressDialog.show(this, "", "努力加载中...", true);
    }

    /**
     * 弹吐司说明
     *
     * @param content 吐司内容
     */
    public void showToast(String content) {
        Toast.makeText(this, content, Toast.LENGTH_SHORT).show();
    }

    /**
     * 关闭延迟弹框
     */
    public void closeProgress() {
        if (null != progressDialog && progressDialog.isShowing())
            progressDialog.cancel();
    }

    /**
     * hook到自己MsgUtils中的add方法 将回调方法改成注解中的方法
     *
     * @param dMethod    方法
     * @param annotation 注解
     * @throws Exception 异常
     */
    private void proxyResult(final Method dMethod, MsgAction annotation) throws Exception {
        Class<?> name = Class.forName("com.lee.basemodel.msg.MsgUtils");
        Method observable = name.getDeclaredMethod("addObservable", String.class, Result.class);

        Object proxy2 = Proxy.newProxyInstance(MsgUtils.class.getClassLoader(), new Class[]{Result.class}, new InvocationHandler() {
            @Override
            public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
                return dMethod.invoke(BaseActivity.this, objects);
            }
        });

        observable.invoke(MsgUtils.getInstance(), annotation.name(), proxy2);
    }

    /**
     * 初始化点击事件注解
     */
    private void initClick() {
        Map<String, Method> mMap = new HashMap<>();
        Method[] declaredMethods = getClass().getDeclaredMethods();
        for (Method method : declaredMethods) {
            Log.i("method", method.toString());
            Click annotation = method.getAnnotation(Click.class);
            if (annotation == null) {
                continue;
            }
            int[] ids = annotation.value();
            mMap.put("setOnClickListener", method);
            for (int id : ids) {
                View view = findViewById(id);
                try {
                    Method onClick = view.getClass().getMethod("setOnClickListener", View.OnClickListener.class);
                    Object proxy = Proxy.newProxyInstance(View.OnClickListener.class.getClassLoader(), new Class[]{View.OnClickListener.class}, new ProxyInvoke(mMap));
                    onClick.invoke(view, proxy);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 代理
     */
    class ProxyInvoke implements InvocationHandler {
        Map<String, Method> map;

        ProxyInvoke(Map<String, Method> map) {
            this.map = map;
        }

        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            Method method1 = map.get("setOnClickListener");

            if (method1 != null) {
                Log.i("invoke", method1.toString());
                return method1.invoke(BaseActivity.this, objects);
            }
            return method.invoke(o, objects);
        }
    }

    /**
     * 初始化完 这里进行操作
     */
    protected abstract void afterInitView();

    /**
     * 初始化各种控件
     */
    private void initViews() {
        Field[] declaredFields = getClass().getDeclaredFields();
        for (Field field : declaredFields) {
            Log.i("field", field.toString());
            BindViews annotation = field.getAnnotation(BindViews.class);
            if (annotation == null) {
                continue;
            }
            View view = findViewById(annotation.value());
            field.setAccessible(true);
            try {
                field.set(this, view);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }


    }

    /**
     * 初始化布局注解
     */
    private void initAnnoLayout() {
        LayoutView annotation = this.getClass().getAnnotation(LayoutView.class);
        if (annotation == null) {
            throw new RuntimeException("如果你的acitivity继承了ModelActivity,你必须在类的前面使用 @LayoutView(R.layout.XXX)");
        }
        setContentView(annotation.value());
    }
}
