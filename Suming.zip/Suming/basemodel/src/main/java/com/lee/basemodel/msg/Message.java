package com.lee.basemodel.msg;

/**
 * Created by lee.
 * Time 2017/1/8 22:16
 */

public class Message {
    public String key;
    public Object object;
    public Result result;
    public Message(String key,Object object){
        this.key = key;
        this.object = object;
    }
    public Message(){

    }
    @Override
    public String toString() {
        return "Message{" +
                "key='" + key + '\'' +
                ", object=" + object +
                '}';
    }

    public static class Builder{
        private String name;
        private Object ob;
        public Builder name (String name){
            this.name = name;
            return this;
        }
        public Builder Content(Object object){
            this.ob = object;
            return this;
        }
        public void send(){
            Message ms = new Message(name,ob);
            MsgUtils.getInstance().sendMsg(ms);
        }
    }
}
