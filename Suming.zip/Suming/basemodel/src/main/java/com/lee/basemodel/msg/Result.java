package com.lee.basemodel.msg;

/**
 * Created by lee.
 * Time 2017/1/8 18:49
 */

public interface Result {
    void getResult(Object t);
}
