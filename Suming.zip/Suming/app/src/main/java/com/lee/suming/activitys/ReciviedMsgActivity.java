package com.lee.suming.activitys;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.lee.basemodel.BaseActivity;
import com.lee.basemodel.anno.BindViews;
import com.lee.basemodel.anno.Click;
import com.lee.basemodel.anno.LayoutView;
import com.lee.basemodel.anno.MsgAction;
import com.lee.suming.R;

/**
 * Created by lee.
 * Time 2017/1/10 10:53
 */

@LayoutView(R.layout.activity_send_msg)
public class ReciviedMsgActivity extends BaseActivity {
    @BindViews(R.id.bt2)
    TextView bt2;
    StringBuilder sb = new StringBuilder();
    @Override
    protected void afterInitView() {
        bt2.setText("2323223");
    }
    @Click(R.id.bt1)
    public void click(View view){
        startActivity(new Intent(this,SendMsgActivity.class));
    }

    @MsgAction(name = "bbb")
    public void getActivity(Object object){
        sb.append(object.toString());
        bt2.setText(sb.toString());
    }
}
