package com.lee.suming.activitys;

import android.view.View;

import com.lee.basemodel.BaseActivity;
import com.lee.basemodel.anno.Click;
import com.lee.basemodel.anno.LayoutView;
import com.lee.basemodel.msg.Message;
import com.lee.suming.R;

/**
 * Created by lee.
 * Time 2017/1/10 21:22
 */
@LayoutView(R.layout.logo4)
public class SendMsgActivity extends BaseActivity {

    @Click(R.id.bt)
    public void click(View view){
        new Thread(){
            @Override
            public void run() {
                for(int i=0;i<50;i++)

                    if(i%2==0) {
                        new Message.Builder().name("aaa").Content(i + " aa").send();
                    }else{
                        new Message.Builder().name("bbb").Content(i + " bb").send();
                    }
                super.run();
            }
        }.start();
        new Thread(){
            @Override
            public void run() {
                for(int i=50;i<100;i++)
                    if(i%2==0) {
                        new Message.Builder().name("aaa").Content(i + " aa").send();
                    }else{
                        new Message.Builder().name("bbb").Content(i + " bb").send();
                    }
                super.run();
            }
        }.start();
        new Thread(){
            @Override
            public void run() {
                for(int i=100;i<150;i++)
                    if(i%2==0) {
                        new Message.Builder().name("aaa").Content(i + " aa").send();
                    }else{
                        new Message.Builder().name("bbb").Content(i + " bb").send();
                    }
                super.run();
            }
        }.start();
    }
    @Override
    protected void afterInitView() {

    }
}
