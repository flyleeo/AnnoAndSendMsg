package com.lee.suming.activitys.net;

import com.lee.suming.activitys.bean.Test;

import retrofit.GsonConverterFactory;
import retrofit.Retrofit;
import retrofit.RxJavaCallAdapterFactory;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by lee.
 * Time 2017/1/13 21:51
 */

public class NetUtils {
    private static final String BASE_URL = "http://www.baidu.com";

    private void getNet() {
        TestNetService testNetService = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())//新的配置
                .baseUrl(BASE_URL)
                .build().create(TestNetService.class);
        Observable<Test> test = testNetService.test("test");
        test.observeOn(Schedulers.io())         //请求完成后在io线程中执行
                .observeOn(AndroidSchedulers.mainThread())//最后在主线程中执行
                .subscribe(new Subscriber<Test>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                    }

                    @Override
                    public void onNext(Test test1) {
                    }
                });

    }
}
