package com.lee.suming.activitys;

import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.lee.basemodel.BaseActivity;
import com.lee.basemodel.anno.BindViews;
import com.lee.basemodel.anno.Click;
import com.lee.basemodel.anno.LayoutView;
import com.lee.basemodel.anno.MsgAction;
import com.lee.suming.R;

/**
 * Created by lee.
 * Time 2016/12/26 15:58
 */
@LayoutView(R.layout.activity_main)
public class MainActivity extends BaseActivity {

    @BindViews(R.id.tv)
    TextView tv;
    boolean b;
    StringBuilder sb = new StringBuilder();

    @Override
    protected void afterInitView() {
        tv.setText("I can do it");
        tv.setTextColor(Color.WHITE);
    }
    @Click({R.id.bt,R.id.bt1})
    public void initClick(View view){
       switch (view.getId()){
           case R.id.bt1:
               startActivity(new Intent(this,ReciviedMsgActivity.class));
               break;
           case R.id.bt:
               Toast.makeText(this,((Button)view).getText().toString(),Toast.LENGTH_SHORT).show();
               break;
       }
    }

    @MsgAction(name = "aaa")
    public void getMsg(Object object) {
        sb.append(object.toString());
        tv.setText(sb.toString());
    }

    @SuppressWarnings(("deprecation"))
    private void aa(){
        Log.e("MainActivity","aa");
    }

}
