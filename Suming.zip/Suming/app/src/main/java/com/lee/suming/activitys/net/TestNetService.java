package com.lee.suming.activitys.net;

import com.lee.suming.activitys.bean.Test;

import retrofit.http.GET;
import retrofit.http.Query;
import rx.Observable;

/**
 * Created by lee.
 * Time 2017/1/13 21:48
 */

public interface TestNetService {
    @GET("demo/test")
    Observable<Test> test(@Query("test") String test);
}
